import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Recipe, RecipeGeneratorState } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Define action types
type RecipeAction = 
  | { type: 'SET_LOADING', payload: boolean }
  | { type: 'ADD_RECIPE', payload: Recipe }
  | { type: 'TOGGLE_FAVORITE', payload: string }
  | { type: 'SET_ERROR', payload: string }
  | { type: 'CLEAR_ERROR' };

// Initial state
const initialState: RecipeGeneratorState = {
  recipes: [],
  favorites: [],
  history: [],
  isLoading: false,
  error: null,
};

// Create context
const RecipeContext = createContext<{
  state: RecipeGeneratorState;
  dispatch: React.Dispatch<RecipeAction>;
  generateRecipe: (prompt: string) => Promise<void>;
}>({
  state: initialState,
  dispatch: () => null,
  generateRecipe: async () => {},
});

// Reducer function
const recipeReducer = (state: RecipeGeneratorState, action: RecipeAction): RecipeGeneratorState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'ADD_RECIPE':
      return {
        ...state,
        recipes: [action.payload, ...state.recipes],
        history: [action.payload, ...state.history],
      };
    case 'TOGGLE_FAVORITE':
      const recipeId = action.payload;
      const isFavorite = state.favorites.some(recipe => recipe.id === recipeId);
      
      if (isFavorite) {
        return {
          ...state,
          favorites: state.favorites.filter(recipe => recipe.id !== recipeId),
          recipes: state.recipes.map(recipe => 
            recipe.id === recipeId ? { ...recipe, isFavorite: false } : recipe
          ),
          history: state.history.map(recipe => 
            recipe.id === recipeId ? { ...recipe, isFavorite: false } : recipe
          ),
        };
      } else {
        const recipe = state.recipes.find(r => r.id === recipeId) || 
                      state.history.find(r => r.id === recipeId);
        if (recipe) {
          return {
            ...state,
            favorites: [...state.favorites, { ...recipe, isFavorite: true }],
            recipes: state.recipes.map(r => 
              r.id === recipeId ? { ...r, isFavorite: true } : r
            ),
            history: state.history.map(r => 
              r.id === recipeId ? { ...r, isFavorite: true } : r
            ),
          };
        }
        return state;
      }
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
};

// Sample data to simulate AI-generated recipes
const getSampleRecipe = (prompt: string): Recipe => {
  // In a real app, this would call an API
  return {
    id: uuidv4(),
    title: `${prompt.charAt(0).toUpperCase() + prompt.slice(1)} Recipe`,
    description: `A delicious ${prompt} recipe generated just for you.`,
    ingredients: [
      '2 cups of main ingredient',
      '1 tablespoon of olive oil',
      '2 cloves of garlic, minced',
      'Salt and pepper to taste',
      '1/4 cup of fresh herbs',
      '1 cup of vegetable broth'
    ],
    instructions: [
      'Prepare all ingredients by washing and chopping as needed.',
      'Heat olive oil in a large pan over medium heat.',
      'Add garlic and sauté until fragrant, about 1 minute.',
      'Add main ingredients and cook for 5-7 minutes.',
      'Pour in vegetable broth and bring to a simmer.',
      'Season with salt and pepper to taste.',
      'Cook until everything is tender and well combined.',
      'Garnish with fresh herbs before serving.'
    ],
    prepTime: '15 minutes',
    cookTime: '25 minutes',
    servings: 4,
    tags: ['easy', 'quick', prompt],
    isFavorite: false
  };
};

// Provider component
export const RecipeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(recipeReducer, initialState);

  // Function to simulate recipe generation
  const generateRecipe = async (prompt: string) => {
    if (!prompt.trim()) {
      dispatch({ type: 'SET_ERROR', payload: 'Please enter a prompt to generate a recipe' });
      return;
    }

    dispatch({ type: 'CLEAR_ERROR' });
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      const newRecipe = getSampleRecipe(prompt);
      dispatch({ type: 'ADD_RECIPE', payload: newRecipe });
    } catch (error) {
      dispatch({ 
        type: 'SET_ERROR', 
        payload: 'Failed to generate recipe. Please try again.' 
      });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  return (
    <RecipeContext.Provider value={{ state, dispatch, generateRecipe }}>
      {children}
    </RecipeContext.Provider>
  );
};

// Custom hook to use the recipe context
export const useRecipe = () => useContext(RecipeContext);