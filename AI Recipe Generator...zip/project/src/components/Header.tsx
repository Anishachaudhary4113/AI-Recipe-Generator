import React from 'react';
import { ChefHat } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="py-6 md:py-8 px-4">
      <div className="container mx-auto flex flex-col items-center">
        <div className="flex items-center gap-2 mb-2">
          <ChefHat size={36} className="text-green-600" />
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">RecipeGenie</h1>
        </div>
        <p className="text-gray-600 text-center max-w-lg">
          Generate delicious recipes with AI. Just describe what you're looking for!
        </p>
      </div>
    </header>
  );
};

export default Header;