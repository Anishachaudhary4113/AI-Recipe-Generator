import React from 'react';
import { Recipe } from '../types';
import { Heart, Clock, Users, Share2, ChevronLeft } from 'lucide-react';
import { useRecipe } from '../context/RecipeContext';

interface RecipeDetailProps {
  recipe: Recipe;
  onBack: () => void;
}

const RecipeDetail: React.FC<RecipeDetailProps> = ({ recipe, onBack }) => {
  const { dispatch } = useRecipe();

  const handleToggleFavorite = () => {
    dispatch({ type: 'TOGGLE_FAVORITE', payload: recipe.id });
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300">
      <div className="relative">
        <div className="h-64 bg-gradient-to-r from-green-100 to-amber-50 flex items-center justify-center">
          {recipe.image ? (
            <img 
              src={recipe.image} 
              alt={recipe.title} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="text-6xl text-amber-700">🍽️</div>
          )}
        </div>
        
        <button 
          onClick={onBack}
          className="absolute top-4 left-4 p-2 bg-white rounded-full shadow-sm hover:shadow-md transition-all"
        >
          <ChevronLeft size={24} className="text-gray-700" />
        </button>
        
        <button 
          onClick={handleToggleFavorite}
          className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-sm hover:shadow-md transition-all"
        >
          <Heart 
            size={24} 
            className={recipe.isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"} 
          />
        </button>
      </div>
      
      <div className="p-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{recipe.title}</h1>
        <p className="text-gray-600 mb-6 text-lg">{recipe.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {recipe.tags.map((tag, index) => (
            <span key={index} className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">
              {tag}
            </span>
          ))}
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-8 p-4 bg-gray-50 rounded-lg">
          <div className="flex flex-col items-center gap-1 text-center">
            <Clock size={24} className="text-green-600" />
            <span className="text-gray-800 font-medium">Prep Time</span>
            <span className="text-gray-600">{recipe.prepTime}</span>
          </div>
          <div className="flex flex-col items-center gap-1 text-center">
            <Clock size={24} className="text-amber-600" />
            <span className="text-gray-800 font-medium">Cook Time</span>
            <span className="text-gray-600">{recipe.cookTime}</span>
          </div>
          <div className="flex flex-col items-center gap-1 text-center">
            <Users size={24} className="text-blue-600" />
            <span className="text-gray-800 font-medium">Servings</span>
            <span className="text-gray-600">{recipe.servings}</span>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Ingredients</h2>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  <span>{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">Instructions</h2>
            <ol className="space-y-4">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center font-medium">
                    {index + 1}
                  </span>
                  <span>{instruction}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
        
        <div className="mt-8 flex justify-end">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <Share2 size={18} />
            <span>Share Recipe</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetail;