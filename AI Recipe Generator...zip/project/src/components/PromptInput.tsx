import React, { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';
import { useRecipe } from '../context/RecipeContext';

const EXAMPLE_PROMPTS = [
  "Healthy vegetarian dinner",
  "Quick breakfast for busy mornings",
  "Italian pasta dish with limited ingredients",
  "Kid-friendly snacks for school",
  "Keto-friendly dessert"
];

const PromptInput: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const { generateRecipe, state: { isLoading } } = useRecipe();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      await generateRecipe(prompt);
      // Keep the prompt in case the user wants to modify and try again
    }
  };

  const handleExampleClick = (example: string) => {
    setPrompt(example);
  };

  return (
    <div className="w-full max-w-3xl mx-auto mb-8">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the recipe you'd like to generate..."
            className="w-full p-4 pr-12 border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all bg-white"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full 
                      ${isLoading || !prompt.trim() 
                      ? 'text-gray-300 cursor-not-allowed' 
                      : 'text-green-600 hover:bg-green-50'} 
                      transition-all`}
          >
            <Send size={20} />
          </button>
        </div>
      </form>

      <div className="mt-4">
        <div className="flex items-center gap-2 mb-2 text-sm text-gray-600">
          <Sparkles size={16} className="text-amber-500" />
          <span>Try these examples:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {EXAMPLE_PROMPTS.map((example, index) => (
            <button
              key={index}
              onClick={() => handleExampleClick(example)}
              className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-full transition-colors text-gray-700"
              disabled={isLoading}
            >
              {example}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PromptInput;