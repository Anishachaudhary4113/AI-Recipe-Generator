import React from 'react';
import { Utensils } from 'lucide-react';

const LoadingState: React.FC = () => {
  return (
    <div className="w-full flex flex-col items-center justify-center py-12">
      <div className="relative">
        <Utensils size={48} className="text-green-600 animate-pulse" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 border-t-2 border-r-2 border-green-600 rounded-full animate-spin"></div>
        </div>
      </div>
      <p className="mt-4 text-gray-600 animate-pulse">Cooking up your recipe...</p>
      <div className="mt-6 grid grid-cols-3 gap-3">
        {[...Array(3)].map((_, index) => (
          <div 
            key={index} 
            className="h-2 bg-gray-200 rounded-full w-16 animate-pulse"
            style={{ animationDelay: `${index * 0.2}s` }}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default LoadingState;