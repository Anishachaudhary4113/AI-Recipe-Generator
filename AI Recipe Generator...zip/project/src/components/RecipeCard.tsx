import React from 'react';
import { Recipe } from '../types';
import { Heart, Clock, Users, Share2 } from 'lucide-react';
import { useRecipe } from '../context/RecipeContext';

interface RecipeCardProps {
  recipe: Recipe;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  const { dispatch } = useRecipe();

  const handleToggleFavorite = () => {
    dispatch({ type: 'TOGGLE_FAVORITE', payload: recipe.id });
  };

  return (
    <div className="w-full bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="relative h-48 bg-gradient-to-r from-green-100 to-amber-50 flex items-center justify-center">
        {recipe.image ? (
          <img 
            src={recipe.image} 
            alt={recipe.title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-4xl text-amber-700">🍽️</div>
        )}
        <button 
          onClick={handleToggleFavorite}
          className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-sm hover:shadow-md transition-all"
        >
          <Heart 
            size={20} 
            className={recipe.isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"} 
          />
        </button>
      </div>
      
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">{recipe.title}</h2>
        <p className="text-gray-600 mb-4">{recipe.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {recipe.tags.map((tag, index) => (
            <span key={index} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
              {tag}
            </span>
          ))}
        </div>
        
        <div className="flex justify-between items-center text-sm text-gray-500 mb-6">
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>{recipe.prepTime} prep</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>{recipe.cookTime} cook</span>
          </div>
          <div className="flex items-center gap-1">
            <Users size={16} />
            <span>{recipe.servings} servings</span>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            View Recipe
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-700 transition-colors">
            <Share2 size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;