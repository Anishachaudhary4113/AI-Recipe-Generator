export interface Recipe {
  id: string;
  title: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  prepTime: string;
  cookTime: string;
  servings: number;
  image?: string;
  tags: string[];
  isFavorite: boolean;
}

export interface RecipeGeneratorState {
  recipes: Recipe[];
  favorites: Recipe[];
  history: Recipe[];
  isLoading: boolean;
  error: string | null;
}