import React, { useState } from 'react';
import Header from '../components/Header';
import PromptInput from '../components/PromptInput';
import LoadingState from '../components/LoadingState';
import RecipeList from '../components/RecipeList';
import RecipeDetail from '../components/RecipeDetail';
import Tabs from '../components/Tabs';
import { Recipe } from '../types';
import { useRecipe } from '../context/RecipeContext';

const Home: React.FC = () => {
  const { state } = useRecipe();
  const [activeTab, setActiveTab] = useState('Generated');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const handleSelectRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
  };

  const handleBackToList = () => {
    setSelectedRecipe(null);
  };

  const getTabContent = () => {
    if (state.isLoading) {
      return <LoadingState />;
    }

    if (selectedRecipe) {
      return <RecipeDetail recipe={selectedRecipe} onBack={handleBackToList} />;
    }

    switch (activeTab) {
      case 'Generated':
        return (
          <RecipeList 
            recipes={state.recipes} 
            onSelectRecipe={handleSelectRecipe}
            emptyMessage="Generate your first recipe by entering a prompt above!"
          />
        );
      case 'Favorites':
        return (
          <RecipeList 
            recipes={state.favorites} 
            onSelectRecipe={handleSelectRecipe}
            emptyMessage="You haven't saved any favorites yet."
          />
        );
      case 'History':
        return (
          <RecipeList 
            recipes={state.history} 
            onSelectRecipe={handleSelectRecipe}
            emptyMessage="Your recipe history will appear here."
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 pb-12">
        {!selectedRecipe && (
          <PromptInput />
        )}
        
        {!state.isLoading && !selectedRecipe && (
          <Tabs 
            tabs={['Generated', 'Favorites', 'History']} 
            activeTab={activeTab} 
            onTabChange={setActiveTab} 
          />
        )}
        
        {state.error && (
          <div className="w-full max-w-3xl mx-auto mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {state.error}
          </div>
        )}
        
        <div className="mt-4">
          {getTabContent()}
        </div>
      </main>
    </div>
  );
};

export default Home;